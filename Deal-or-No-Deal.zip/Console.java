class Console {
  public static void clearScreen() {   
    for (int i = 0; i < 1000; i++)
      System.out.println(" "); 
  }
}